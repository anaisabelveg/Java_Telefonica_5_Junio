package com.telefonica;

import com.telefonica.models.Figura;
import com.telefonica.models.Triangulo;

public class AppMain {

	public static void main(String[] args) {
		
		// Las clases abstractas no se pueden instanciar
		//Figura figura = new Figura();
		
		// Pero si se pueden utilizar como tipo de dato
		Figura triangulo = new Triangulo(4,3,10,20);
		System.out.println("Posicion: " + triangulo.posicion());
		System.out.println("Area: " + triangulo.area());

	}

}
