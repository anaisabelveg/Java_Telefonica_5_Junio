package com.telefonica.models;

public interface ProductoVenta {
	
	// En una interface todas las propiedades se consideran constantes
	
	// Todos los metodos se consideran publicos y abstractos
	double getPrecio();
	String getCodigo();
	
	void setPrecio(double precio);
	void setCodigo(String codigo);

}
