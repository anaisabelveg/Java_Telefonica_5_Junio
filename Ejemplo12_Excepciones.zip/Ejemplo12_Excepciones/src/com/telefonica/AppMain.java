package com.telefonica;

import java.util.Scanner;

import com.telefonica.utils.NegativoException;

public class AppMain {

	// Propagar la excepcion
	public static void main(String[] args) throws NegativoException {
		
		String[] datos = {"1", "dos", "3", "4", "5"};
		int suma = 0;
		
		for (String texto : datos) {
			
			try {
				int num = Integer.parseInt(texto);
				suma += num;
			} catch(NumberFormatException ex) {
				System.out.println("No es numerico " + ex.getMessage());
				ex.printStackTrace();
			} catch(Exception ex) {
				System.out.println("Ha ocurrido un error " + ex.getMessage());
			}
				
		}
		
		System.out.println("Suma: " + suma);
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce tu edad: ");
		int edad = sc.nextInt();
		
		// Si la edad es negativa lanzamos excepcion
		if (edad < 0) {
			throw new NegativoException("La edad no puede ser negativa");
		}
		

	}

}








