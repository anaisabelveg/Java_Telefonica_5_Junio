package com.telefonica.utils;

/*
	Las excepciones en Java pueden ser de 2 tipos:
		- checked: me obliga a manejar la excepcion (extends Exception)
		- unchecked: no me obliga a manejar la excepcion (extends RuntimeException)
*/

public class NegativoException extends Exception{
	
	public NegativoException(String mensaje) {
		super(mensaje);
	}

}
