package com.telefonica;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		
		// Set: No permite duplicados, No se garantiza orden de entrada
		Set numeros = new HashSet();
		numeros.add(1);
		numeros.add("dos");
		numeros.add(new Integer(3));
		numeros.add("dos");  // los duplicados los ignora
		
		System.out.println(numeros);
		
		
		// List: Si permite duplicados, Si se garantiza orden de entrada
		List lista = new ArrayList();
		lista.add(1);
		lista.add("dos");
		lista.add(new Integer(3));
		lista.add("dos"); 
		System.out.println(lista);
		
		
		// A partir de Java 5 yo puedo limitar el tipo de los elementos
		Set<Integer> numeros2 = new HashSet<Integer>();
		numeros2.add(1);
		//numeros2.add("dos");  // Error de compilacion
		numeros2.add(new Integer(3));
		//numeros2.add("dos");  // Error de compilacion
		
		// A partir de Java 7 no es necesario el tipo generico en el contructor
		List<String> nombres = new ArrayList<>();
		nombres.add("Juan");
		nombres.add("Luis");
		nombres.add("Pedro");
		
		
		// Map: cada elemento es key=value
		Map<String, Double> alumnos = new HashMap<String, Double>();
		alumnos.put("Juan", 6.3);
		alumnos.put("Luis", 7.1);
		alumnos.put("Pedro", 4.2);
		System.out.println(alumnos);

	}

}
