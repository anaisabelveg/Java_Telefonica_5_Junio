package com.telefonica;

import com.telefonica.models.Producto;
import com.telefonica.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		for(Producto p: dao.consultarTodos()) {
			System.out.println(p);
		}

	}

}
