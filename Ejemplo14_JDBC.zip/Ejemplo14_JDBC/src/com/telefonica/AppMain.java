package com.telefonica;

import com.telefonica.models.Producto;
import com.telefonica.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		dao.alta(new Producto(4, "Impresora", 86.90));
		
		for(Producto p: dao.consultarTodos()) {
			System.out.println(p);
		}

	}

}
