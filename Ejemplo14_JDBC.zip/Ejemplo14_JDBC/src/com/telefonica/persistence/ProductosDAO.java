package com.telefonica.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.telefonica.models.Producto;

// DAO -> Data Access Object
public class ProductosDAO {
	
	private Connection conexion;
	
	public List<Producto> consultarTodos(){
		List<Producto> lista = new ArrayList<Producto>();
		
		try {
			abrirConexion();
			// Statement -> Queries sin parametros
			Statement stm = conexion.createStatement();
			ResultSet rs = stm.executeQuery("select * from PRODUCTOS");
			while (rs.next()) {
				Producto producto = new Producto(rs.getInt("ID"), 
						rs.getString("DESCRIPCION"), rs.getDouble("PRECIO"));
				lista.add(producto);			
			}
			
		} catch (Exception e) {
			System.out.println("Error al consultar todos los productos");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return lista;
	}
	
	public void abrirConexion() {	
		try {
			// Cargar el driver de la BBDD
			Class.forName("com.mysql.jdbc.Driver");
			
			// Abrir la conexion
			conexion = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/telefonica", "root", "");
		} catch (ClassNotFoundException e) {
			System.out.println("Error al cargar el driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Error al abrir la conexion");
			e.printStackTrace();
		}	
	}
	
	public void cerrarConexion() {
		try {
			conexion.close();
		} catch (SQLException e) {
			System.out.println("Error al cerrar la conexion");
			e.printStackTrace();
		}
	}

}
