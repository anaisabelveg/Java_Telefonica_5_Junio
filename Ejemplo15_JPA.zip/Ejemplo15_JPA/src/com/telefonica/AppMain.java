package com.telefonica;

import com.telefonica.models.Producto;
import com.telefonica.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		dao.alta(new Producto(5, "Scanner", 100));
		
		for(Producto p: dao.consultarTodos()) {
			System.out.println(p);
		}

	}

}
