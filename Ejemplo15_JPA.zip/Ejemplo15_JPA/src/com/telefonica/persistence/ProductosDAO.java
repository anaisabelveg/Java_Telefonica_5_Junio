package com.telefonica.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.telefonica.models.Producto;

// DAO -> Data Access Object
public class ProductosDAO {
	
	private Connection conexion;
	
	public void alta(Producto nuevo) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		try {
			et.begin();
			em.persist(nuevo);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			System.out.println("Error al insertar nuevo producto");
			e.printStackTrace();
		}
	}
	
	public List<Producto> consultarTodos(){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		Query query = em.createQuery("select p from Producto p");	
		List<Producto> lista = query.getResultList();
		return lista;
	}
	
	

}
