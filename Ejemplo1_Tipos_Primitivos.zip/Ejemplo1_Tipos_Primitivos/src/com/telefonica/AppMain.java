package com.telefonica;

public class AppMain {

	// Marca el punto de entrada de la aplicacion
	public static void main(String[] args) {
		
		/*
		 * Ejemplo para mostrar los tipos primitivos
		 * */
		
		// Numericos enteros
		byte numByte = (byte) 8; 			 // 8 bits
		short numShort = (short) 250; 		 // 16 bits
		int numInteger = 67764332;           // 32 bits (defecto)
		long numLong = 543235788643215567L;  // 64 bits sufijo l o L
		
		// Numericos reales
		float numFloat = 1.87F;				 // 32 bits sufijo f o F
		double numDouble = 67878.556;        // 64 bits
		
		// Booleanos: true y false
		boolean soltero = true;
		boolean incidencia = false;
		
		// Caracter: 'caracter'
		char letra = 'h';
		char sexo = 'M';
		char puntoCardinal = 'N';
		
		// String es una clase, no un tipo primitivo
		// Las clases se escriben con la primera letra en mayuscula
		// Las cadenas de texto van entre comillas dobles
		String nombre = "Anabel";
		
		
		// Mostrar la informacion por consola
		// atajo syso + ctrl + space
		System.out.println("numByte: " + numByte);
		System.out.println("numShort: " + numShort);
		System.out.println("numInteger: " + numInteger);
		System.out.println("numLong: " + numLong);
		System.out.println("numFloat: " + numFloat);
		System.out.println("numDouble: " + numDouble);
		System.out.println("Soltero: " + soltero);
		System.out.println("Letra: " + letra);
		System.out.println("Nombre: " + nombre);

	}  // Fin del metodo main

}  // Fin de la clase
