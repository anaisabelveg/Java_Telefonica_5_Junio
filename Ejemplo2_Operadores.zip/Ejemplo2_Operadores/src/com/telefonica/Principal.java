package com.telefonica;

public class Principal {

	public static void main(String[] args) {
		// Operadores aritmeticos
		int num1 = 7;
		int num2 = 3;
		
		// operador de concatenacion izda a dcha
		System.out.println("Suma: " + (num1 + num2) );
		System.out.println("Resta: " + (num1 - num2) );
		System.out.println("Multiplicacion: " + (num1 * num2) );
		System.out.println("Division: " + (num1 / num2) );
		System.out.println("Resto: " + (num1 % num2) );
		
		// Incrementos y decrementos
		num2++;    //  num2 = num2 + 1;
		num2--;    //  num2 = num2 - 1;
		
		num2 = 10;
		int resultado = num2++;  // post-incremento   1º asigna, 2º incrementa
		resultado = ++num2;		 // pre-incremento    1º incrementa, 2º asigna
		System.out.println(resultado);
		System.out.println(num2);
		
		
		// Operadores de comparacion
		System.out.println("Es mayor el numero 2? " + (num2 > num1));
		System.out.println("Es mayor o igual el numero 2? " + (num2 >= num1));
		System.out.println("Es menor el numero 2? " + (num2 < num1));
		System.out.println("Es menor o igual el numero 2? " + (num2 <= num1));
		System.out.println("Son iguales? " + (num2 == num1));
		System.out.println("Son distintos? " + (num2 != num1));
		
		
		// Operadores logicos
		System.out.println("AND: " + ((num1 > 5) && (num2 < 10)));
		System.out.println("OR: " + ((num1 > 5) || (num2 < 10)));
		System.out.println("NOT: " + (!(num2 < 10)));
		
		
		// Operadores de asignacion
		num2 = 10;
		num2 += 5;   // num2 = num2 + 5;
		num2 -= 5;   // num2 = num2 - 5;
		num2 *= 5;   // num2 = num2 * 5;
		num2 /= 5;   // num2 = num2 / 5;
		num2 %= 5;   // num2 = num2 % 5;
		
	}

}








