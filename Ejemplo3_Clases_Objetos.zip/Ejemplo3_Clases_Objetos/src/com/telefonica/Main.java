package com.telefonica;

// Siempre que utilizo clases de otros paquetes hay que importarlas
import com.telefonica.models.Empleado;

public class Main {

	public static void main(String[] args) {
		
		// Crear objetos o instancias de Empleado
		
		// En Java, las clases pueden ser tipos de datos
		Empleado juan = new Empleado();
		juan.numEmpleado = 1;   // . operador de acceso a miembro
		juan.nombre = "Juan";
		juan.sueldo = 54000;
		
		juan.cambiarSueldo(58000);
		juan.mostrarDetalle();
		System.out.println(juan.verNombre());
		
		Empleado maria = new Empleado(2, "Maria", 61000);
		maria.cambiarSueldo(juan.sueldo);
		maria.mostrarDetalle();
		
		// Asigno el puntero de juan a maria
		maria = juan;
		maria.mostrarDetalle();
		juan.mostrarDetalle();

	}

}
