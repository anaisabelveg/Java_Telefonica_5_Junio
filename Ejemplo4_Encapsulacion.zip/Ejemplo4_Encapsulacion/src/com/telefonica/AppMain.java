package com.telefonica;

import com.telefonica.models.Fecha;
import com.telefonica.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		
		Fecha fecha = new Fecha();
		fecha.dia = 5;
		fecha.mes = 6;
		fecha.anyo = 2023;
		fecha.mostrar();
		
		Fecha fechaErronea = new Fecha();
		fechaErronea.dia = -5677;
		fechaErronea.mes = 678;
		fechaErronea.anyo = -0;
		fechaErronea.mostrar();
		
		FechaEncapsulada fechaEncapsulada = new FechaEncapsulada();
		fechaEncapsulada.setDia(-5677);
		fechaEncapsulada.setMes(678);
		fechaEncapsulada.setAnyo(-0);
		fechaEncapsulada.mostrar();
		
		FechaEncapsulada fechaEncapsulada2 = new FechaEncapsulada();
		fechaEncapsulada2.setDia(5);
		fechaEncapsulada2.setMes(6);
		fechaEncapsulada2.setAnyo(2023);
		fechaEncapsulada2.mostrar();

	}

}
