package com.telefonica;

import com.telefonica.models.Direccion;
// Siempre que utilizo clases de otros paquetes hay que importarlas
import com.telefonica.models.Empleado;

public class Main {

	public static void main(String[] args) {
		
		// Crear objetos o instancias de Empleado
		Direccion dirMaria = new Direccion("Mayor", 5, "Madrid");
		Empleado maria = new Empleado(1, "Maria", 61000, dirMaria);
		maria.mostrarDetalle();
		
		// Asigno el puntero de juan a maria
		Empleado juan = new Empleado(2, "Juan", 58000, 
				new Direccion("Diagonal", 28, "Barcelona"));
		juan.mostrarDetalle();

	}

}
