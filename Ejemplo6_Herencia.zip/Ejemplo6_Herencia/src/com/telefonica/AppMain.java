package com.telefonica;

import com.telefonica.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Empleado empleado1 = new Empleado("Juan", 37, 1, 57_000);
		Empleado empleado2 = new Empleado("Juan", 37, 1, 57_000);
		
		System.out.println(empleado1);
		
		// El operador == compara el contenido de las variables
		// En el caso de los objetos, la variable contiene direccion de memoria
		System.out.println("Son iguales? " + (empleado1 == empleado2));
		
		// Para comparar objetos utilizamos el metodo equals()
		System.out.println("Son iguales? " + (empleado1.equals(empleado2)));
		
	}

}
