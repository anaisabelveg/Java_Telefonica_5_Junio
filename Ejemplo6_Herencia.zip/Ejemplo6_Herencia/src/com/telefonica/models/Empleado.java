package com.telefonica.models;

import java.util.Objects;

// Heredamos todos los recursos que no son privados
public class Empleado extends Persona {

	// Podemos agregar nuevos recursos
	private int numEmpleado;
	private double sueldo;

	public Empleado() {
		// implicitamente en todos los constructores la primera linea es super()
		super();
	}

	public Empleado(String nombre, int edad, int numEmpleado, double sueldo) {
		// Estamos llamando al constructor de la superclase
		// Esta llamada super() solo se puede utilizar dentro del contructor
		super(nombre, edad);
		this.numEmpleado = numEmpleado;
		this.sueldo = sueldo;
	}

	public int getNumEmpleado() {
		return numEmpleado;
	}

	public void setNumEmpleado(int numEmpleado) {
		this.numEmpleado = numEmpleado;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		// El puntero super. llama a la instancia de la superclase
		// super.toString()   llama al toString() de la clase Persona
		return  super.toString() + " numEmpleado=" + numEmpleado + " sueldo=" + sueldo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(numEmpleado, sueldo);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		return  super.equals(obj) && numEmpleado == other.numEmpleado
				&& Double.doubleToLongBits(sueldo) == Double.doubleToLongBits(other.sueldo);
	}
	
	

}
