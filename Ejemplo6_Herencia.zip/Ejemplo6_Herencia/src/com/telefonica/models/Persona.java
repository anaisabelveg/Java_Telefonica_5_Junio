package com.telefonica.models;

import java.util.Objects;

// Todas las clases directa o indirectamente heredan de la clase Object
// Si el compilador ve que la clase no hereda de ninguna, añade extends Object
//public class Persona extends Object{
// en lo mismo que:
public class Persona{
	
	private String nombre;
	private int edad;
	
	// Es recomendable mantener siempre el constructor por defecto
	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String nombre, int edad) {
		super();  // invoca al constructor de Object()
		this.nombre = nombre;
		this.edad = edad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	@Override
	public String toString() {
		return "nombre=" + nombre + " edad=" + edad;
	}

	@Override
	public int hashCode() {
		return Objects.hash(edad, nombre);
	}

	@Override
	public boolean equals(Object obj) {	
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		// Polimorfismo - cambio la visibilidad a Persona
		Persona other = (Persona) obj;
		return edad == other.edad && Objects.equals(nombre, other.nombre);
	}
	
	
	

}
