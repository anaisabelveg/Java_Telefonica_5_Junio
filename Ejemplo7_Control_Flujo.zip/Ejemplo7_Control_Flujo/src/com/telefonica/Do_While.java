package com.telefonica;

import java.util.Scanner;

public class Do_While {

	public static void main(String[] args) {
		
		// Generar un numero entre 1 y 10
		int aleatorio = (int)(Math.random() * 10 + 1);
		int numero = 0;
		Scanner sc;
		
		do {
			sc = new Scanner(System.in);
			System.out.println("Introduce numero del 1 al 10: ");
			numero = sc.nextInt();
			
			if (numero > aleatorio) {
				System.out.println("Te has pasado, prueba con un numero menor");
			} else if (numero < aleatorio) {
				System.out.println("Te has quedado corto, prueba con un numero mayor");
			} else {
				System.out.println("Has acertado");
			}
			
		} while(aleatorio != numero);
		sc.close();

	}

}
