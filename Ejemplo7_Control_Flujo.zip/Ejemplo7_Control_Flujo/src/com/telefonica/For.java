package com.telefonica;

public class For {

	public static void main(String[] args) {
		
		// Mostrar los numeros del 1 al 10
		for(int i = 1; i <= 10; i+=2) {
			System.out.println(i);
		}
		
		// A partir de Java 5 for-each
		String[] nombres = {"Juan", "Maria", "Pedro"};
		for (String name : nombres) {
			System.out.println(name);
		}

	}

}
