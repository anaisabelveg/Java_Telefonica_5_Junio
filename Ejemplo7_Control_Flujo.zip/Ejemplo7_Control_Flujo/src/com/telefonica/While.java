package com.telefonica;

import java.util.Scanner;

public class While {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce pw:");
		String pw = sc.next();
		
		while (! "curso".equals(pw)) {
			System.out.println("Error, vuelve a intentarlo");
			System.out.println("Introduce pw:");
			pw = sc.next();
		}
		
		System.out.println("Acertaste");
		sc.close();

	}

}
