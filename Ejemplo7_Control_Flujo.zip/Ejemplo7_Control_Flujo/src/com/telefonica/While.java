package com.telefonica;

public class While {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
