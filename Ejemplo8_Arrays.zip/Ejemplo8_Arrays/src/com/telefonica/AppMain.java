package com.telefonica;

import java.util.Arrays;

public class AppMain {

	public static void main(String[] args) {
		
		// Declarar una variable de tipo array
		int numeros[];
		//String [] nombres;
		//char[] letras;
		
		// Crear el array
		numeros = new int[4];
		
		// Asignar valores al array
		numeros[0] = 6;
		numeros[1] = 9;
		numeros[2] = 4;
		numeros[3] = 1;
		
		// Todo en uno
		String [] nombres = {"Marta", "Juan", "Lola", "Antonio", "Luis"};	
		char[] letras = new char[] {'a', 'e', 'i', 'o', 'u'};
		
		// Mostrar un array
		System.out.println(letras);
		System.out.println(Arrays.toString(letras));
		
		// Recorrer el array
		for (char c : letras) {
			System.out.println(c);
		}
		
		for (int i=0; i < numeros.length; i++) {
			System.out.println(numeros[i]);
		}
		
		// Los string no son mutables, no son modificables
		String cadena = "";
		for (String name : nombres) {
			cadena += name + " ";
		}
		System.out.println(cadena);
		
		// Es mejor utilizar StringBuilder
		StringBuilder cadenaBuild = new StringBuilder();
		for (String name : nombres) {
			cadenaBuild.append(name);
			cadenaBuild.append(" ");
		}
		System.out.println(cadenaBuild);
		
		
		/**
		 * 
		 * ARRAYS DE 2 DIMENSIONES (fila, columna)
		 * 
		 **/
		
		int matriz[][];
		matriz = new int[2][3];  // 2 filas y 3 columnas
		matriz[0][0] = 5;
		matriz[0][1] = 1;
		matriz[0][2] = 7;
		matriz[1][0] = 8;
		matriz[1][1] = 2;
		matriz[1][2] = 4;
		
		int matriz2[][] = { {5,1,7}, {8,2,4} };
		
		for (int[] fila : matriz2) {
			for (int num : fila) {
				System.out.print(num + " ");
			}
			System.out.println();
		}
		
		
		for (int fila = 0; fila < matriz2.length; fila++) {
			for (int col = 0 ; col < matriz2[fila].length; col++) {
				System.out.print(matriz2[fila][col] + " ");
			}
			System.out.println();
		}

	}
	
	
	

}
