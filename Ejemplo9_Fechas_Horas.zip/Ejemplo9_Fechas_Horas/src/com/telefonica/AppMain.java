package com.telefonica;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;

public class AppMain {

	public static void main(String[] args) {
		
		// La clase Date no es mutable
		Date ahora = new Date();
		System.out.println(ahora);
		
		// LocalDate (solo para fechas)
		System.out.println(LocalDate.now());  
		System.out.println(LocalDate.of(2023, 8, 25));  
		System.out.println(LocalDate.now().isBefore(LocalDate.of(2023, 8, 25))); 
		System.out.println(LocalDate.now().isAfter(LocalDate.of(2023, 8, 25))); 
		System.out.println(LocalDate.now().isLeapYear()); 
		System.out.println(LocalDate.now().getDayOfWeek());
		System.out.println(LocalDate.now().plusMonths(1)); 
		System.out.println(LocalDate.now().plusWeeks(1));  
		System.out.println(LocalDate.now().plusYears(1)); 
		System.out.println(LocalDate.now().plusDays(1)); 
		
		// Cambiar el formato
		DateTimeFormatter miFormato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String hoy = LocalDate.now().format(miFormato);
		System.out.println(hoy);
		
		// Hora en milisegundos
		System.out.println(System.currentTimeMillis());
		
		// Hora en nanosegundos
		System.out.println(System.nanoTime());
		
		
		// LocalTime  (solo para horas)
		System.out.println(LocalTime.now());
		System.out.println(LocalTime.now().truncatedTo(ChronoUnit.MINUTES));
		System.out.println(LocalTime.now().truncatedTo(ChronoUnit.HOURS));
		System.out.println(LocalTime.now().plusHours(2).plusMinutes(30));
		System.out.println(LocalTime.now().toSecondOfDay());
		System.out.println(LocalTime.now().toNanoOfDay());
		System.out.println(LocalTime.now().isAfter(LocalTime.of(10, 0)));
		System.out.println(LocalTime.now().isBefore(LocalTime.of(14, 0)));
		System.out.println(LocalTime.now().until(LocalTime.of(14, 0), ChronoUnit.SECONDS));
		
		// LocalDateTime  (fechas y horas)
		System.out.println(LocalDateTime.now());
		System.out.println(LocalDateTime.of(2023, 6, 6, 13, 49));
		System.out.println(LocalDateTime.of(LocalDate.now(), LocalTime.now()));
		System.out.println(LocalDateTime.now().plusDays(3).plusMinutes(10));
		System.out.println(LocalDateTime.now().toLocalDate());  // solo la fecha
		System.out.println(LocalDateTime.now().toLocalTime());  // solo la hora
	}

}
